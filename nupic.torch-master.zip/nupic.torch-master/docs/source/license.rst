License
=======

.. include:: ../../LICENSE
   :literal:

