
.. include:: ../../README.md
   :parser: myst_parser.sphinx_

Contents
========

.. toctree::

   modules
   license
   todo

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
