# Changelog
All notable changes to this project will be documented in this file.

## v0.0.1.dev
### Pending
- Release process established, including pypi deployment via CircleCI.
