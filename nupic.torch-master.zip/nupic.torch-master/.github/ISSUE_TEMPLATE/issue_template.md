---
name: New nupic.torch issue
about: Default issue template
title: ''
labels: ''
assignees: ''

---

Before reporting a new feature or bug, please [see current issues](https://github.com/numenta/nupic.torch/issues) first to avoid duplication. 

Please provide a list of commands to replicate the bug, and any text-based console output.

See https://github.com/numenta/nupic.torch/blob/master/CONTRIBUTING.md for more details.