# Create pretrained GSC models

This example shows how the pretrained GSC models were trained.

```
pip install -r requirements.txt
python download_data.py
python preprocess_data.py
python train_model.py
python train_model.py --supersparse
```
